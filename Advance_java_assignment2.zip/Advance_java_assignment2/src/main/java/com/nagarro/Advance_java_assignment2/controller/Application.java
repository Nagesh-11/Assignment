package com.nagarro.Advance_java_assignment2.controller;

import java.io.IOException;
import java.util.List;

import com.nagarro.Advance_java_assignment2.domain.TShirt;
import com.nagarro.Advance_java_assignment2.dto.TShirtSearchDTO;
import com.nagarro.Advance_java_assignment2.service.TShirtSearchService;
import com.nagarro.Advance_java_assignment2.view.Input;
import com.nagarro.Advance_java_assignment2.view.Output;

public class Application {

	public static void main(String args[]) throws IOException
	{
		Input input = new Input();
		TShirtSearchDTO tShirtSearchDTO = input.getDetails();
		
		TShirtSearchService tShirtSearchService = new TShirtSearchService();
		List<TShirt> matchingShirts = tShirtSearchService.getMatchingTShirts(tShirtSearchDTO);
		
		Output output = new Output();
		output.displayAllShirts(matchingShirts);
	}
}
