package com.nagarro.Advance_java_assignment2.dto;

public class TShirtSearchDTO {
	private String color;
	private String gender;
	private String size;
	private int outputPreference;

	public TShirtSearchDTO() {
	}

	public TShirtSearchDTO(String color, String gender, String size, int outputPreference) {
		super();
		this.color = color;
		this.gender = gender;
		this.size = size;
		this.outputPreference = outputPreference;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getOutputPreference() {
		return outputPreference;
	}

	public void setOutputPreference(int outputPreference) {
		this.outputPreference = outputPreference;
	}

}
